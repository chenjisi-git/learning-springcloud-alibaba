package com.example.api.code.email.service;

/**
 * The interface Code email rpc.
 *
 * @author aleng
 * @version 1.0.0
 * @className CodeEmailRpc
 * @description TODO
 * @createTime 2020年12月27日 16:55:00
 */
public interface CodeEmailRpc {

  /**
   * Send email boolean.
   *
   * @param email the email
   * @param code the code
   * @return the boolean
   */
  Boolean sendEmail(String email, String code);
}
