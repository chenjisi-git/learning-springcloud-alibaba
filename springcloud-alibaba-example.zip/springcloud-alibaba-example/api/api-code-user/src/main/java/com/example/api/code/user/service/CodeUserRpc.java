package com.example.api.code.user.service;

/**
 * The interface Code user rpc.
 *
 * @author aleng
 * @version 1.0.0
 * @className CodeUserRpc
 * @description TODO
 * @createTime 2020年12月27日 16:55:00
 */
public interface CodeUserRpc {

  /**
   * Save user boolean.
   *
   * @param email the email
   * @param code the code
   * @return the boolean
   */
  Boolean saveUser(String email, String code);

  /**
   * Is registered boolean.
   *
   * @param email the email
   * @return the boolean
   */
  Boolean isRegistered(String email);
}
