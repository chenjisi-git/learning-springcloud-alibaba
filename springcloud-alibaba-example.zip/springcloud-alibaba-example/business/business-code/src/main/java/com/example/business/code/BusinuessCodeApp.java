package com.example.business.code;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * BusinuessCodeApp
 *
 * @author aleng
 * @version 1.0
 * @since 2020/12/21 15:50
 */
@EnableDiscoveryClient
@SpringBootApplication
public class BusinuessCodeApp {
  public static void main(final String[] args) {
    SpringApplication.run(BusinuessCodeApp.class, args);
  }
}
