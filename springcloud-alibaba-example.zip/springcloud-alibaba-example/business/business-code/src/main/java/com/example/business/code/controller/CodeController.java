package com.example.business.code.controller;

import com.example.api.code.email.service.CodeEmailRpc;
import com.example.api.code.user.service.CodeUserRpc;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * CodeController
 *
 * @author aleng
 * @version 1.0
 * @since 2020 /12/21 15:52
 */
@RestController
@RequestMapping("/code")
public class CodeController {

  @DubboReference CodeEmailRpc codeEmailRpc;
  @DubboReference CodeUserRpc codeUserRpc;

  /**
   * createCode
   *
   * @param email the email
   * @return the boolean
   */
  @PostMapping("/create/{email}")
  public Boolean createCode(@PathVariable final String email) {
    final String code = (int) ((Math.random() * 9 + 1) * 100000) + "";
    if (codeUserRpc.isRegistered(email)) {
      return false;
    }
    codeEmailRpc.sendEmail(email, code);
    codeUserRpc.saveUser(email, code);
    System.out.println(code);
    return true;
  }

  /**
   * verifyCode
   *
   * @param email the email
   * @param code the code
   * @return the boolean
   */
  @PostMapping("/validate/{email}/{code}")
  public Integer verifyCode(@PathVariable final String email, @PathVariable final String code) {
    return 0;
  }
}
