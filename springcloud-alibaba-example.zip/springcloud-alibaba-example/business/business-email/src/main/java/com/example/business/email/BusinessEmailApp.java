package com.example.business.email;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * BusinessEmailApp
 *
 * @author aleng
 * @version 1.0
 * @since 2020/12/21 15:47
 */
@EnableDiscoveryClient
@SpringBootApplication
public class BusinessEmailApp {
  public static void main(final String[] args) {
    SpringApplication.run(BusinessEmailApp.class, args);
  }
}
