package com.example.business.email.provider;

import cn.hutool.extra.mail.MailUtil;
import com.example.api.code.email.service.CodeEmailRpc;
import org.apache.dubbo.config.annotation.DubboService;

/**
 * @author aleng
 * @version 1.0.0
 * @className CodeEmailRpcImpl
 * @description TODO
 * @createTime 2020年12月27日 17:30:00
 */
@DubboService
public class CodeEmailRpcImpl implements CodeEmailRpc {

    @Override
    public Boolean sendEmail(final String email, final String code) {
        MailUtil.send(email, "Verification Code", code, false);
        return true;
    }
}
