package com.example.business.user.cache;

import com.example.business.user.entity.AuthCode;
import com.example.business.user.entity.Token;
import com.example.business.user.entity.User;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

/**
 * UserCache
 *
 * @author aleng
 * @version 1.0
 * @since 2020/12/21 20:40
 */
public class UserCache {

  public static final ConcurrentHashMap<String, User> USER_MAP = new ConcurrentHashMap();

  public static final Cache<String, Token> TOKEN_CACHE =
      Caffeine.newBuilder()
          // 设置最后一次写入或访问后经过固定时间过期
          .expireAfterAccess(10, TimeUnit.MINUTES)
          // 初始的缓存空间大小
          .initialCapacity(100)
          // 缓存的最大条数
          .maximumSize(100)
          .build();

  public static final Cache<String, AuthCode> CODE_CACHE =
      Caffeine.newBuilder()
          // 设置最后一次写入或访问后经过固定时间过期
          .expireAfterWrite(10, TimeUnit.MINUTES)
          // 初始的缓存空间大小
          .initialCapacity(10000)
          // 缓存的最大条数
          .maximumSize(100000)
          .build();
}
