package com.example.business.user.controller;

import cn.hutool.core.lang.Snowflake;
import cn.hutool.core.util.IdUtil;
import com.example.business.user.cache.UserCache;
import com.example.business.user.entity.AuthCode;
import com.example.business.user.entity.Token;
import com.example.business.user.entity.User;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

/**
 * 用户操作入口
 *
 * @author aleng
 * @version 1.0
 * @since 2020 /12/21 18:13
 */
@RestController
@RequestMapping("/user")
public class UserController {

  /**
   * register
   *
   * @param email the email
   * @param password the password
   * @param code the code
   * @return the boolean
   */
  @PostMapping("/register/{email}/{password}/{code}")
  public Boolean register(
      @PathVariable final String email,
      @PathVariable final String password,
      @PathVariable final String code) {
    final AuthCode authCode = UserCache.CODE_CACHE.getIfPresent(code);
    if (null != authCode && email.equals(authCode.getEmail())) {
      final Snowflake snowflake = IdUtil.createSnowflake(1, 1);
      UserCache.USER_MAP.put(
          email, new User().setId(snowflake.nextId()).setEmail(email).setPassword(password));
      return true;
    }
    return false;
  }

  /**
   * login
   *
   * @param email the email
   * @param password the password
   * @return the boolean
   */
  @PostMapping("/login/{email}/{password}")
  public Boolean login(
          @PathVariable final String email,
          @PathVariable final String password,
          final HttpServletResponse response) {
    final User user = UserCache.USER_MAP.get(email);
    if (null == user || !password.equals(user.getPassword())) {
      return false;
    } else {
      final String token = IdUtil.fastUUID();
      final Cookie cookie = new Cookie("token", token);
      // 设置为30min
      cookie.setMaxAge(30 * 60);
      cookie.setPath("/");
      response.addCookie(cookie);
      UserCache.TOKEN_CACHE.put(token, new Token().setToken(token).setEmail(email));
      return true;
    }
  }

  /**
   * info
   *
   * @param token the token
   * @return the boolean
   */
  @PostMapping("/info/{token}")
  public ResponseEntity<String> info(@PathVariable final String token) {
    final Token tokenEntity = UserCache.TOKEN_CACHE.getIfPresent(token);
    HttpStatus status = HttpStatus.OK;
      if (null == tokenEntity) {
        status = HttpStatus.UNAUTHORIZED;
        return new ResponseEntity<String>("token不正确", status);
      } else {
      return new ResponseEntity<String>(tokenEntity.getEmail(), status);
    }
  }
}
