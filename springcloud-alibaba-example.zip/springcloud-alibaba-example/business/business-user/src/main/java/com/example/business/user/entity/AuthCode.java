package com.example.business.user.entity;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * AuthCode
 *
 * @author aleng
 * @version 1.0
 * @since 2020 /12/21 20:33
 */
@Data
@Accessors(chain = true)
public class AuthCode {
  private Long id;
  private String email;
  private String code;
  private Date createTime;
}
