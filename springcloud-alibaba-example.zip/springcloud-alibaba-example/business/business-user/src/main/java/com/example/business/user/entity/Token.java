package com.example.business.user.entity;

import lombok.Data;
import lombok.experimental.Accessors;

/**
 * Token
 *
 * @author aleng
 * @version 1.0
 * @since 2020 /12/21 20:39
 */
@Data
@Accessors(chain = true)
public class Token {

  private Long id;
  private String email;
  private String token;
}
