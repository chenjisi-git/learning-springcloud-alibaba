package com.example.business.user.provider;

import cn.hutool.core.lang.Snowflake;
import cn.hutool.core.util.IdUtil;
import com.example.api.code.user.service.CodeUserRpc;
import com.example.business.user.cache.UserCache;
import com.example.business.user.entity.AuthCode;
import org.apache.dubbo.config.annotation.DubboService;

import java.util.Date;

/**
 * The type Code user rpc.
 *
 * @author aleng
 * @version 1.0.0
 * @className CodeUserRpcImpl
 * @description TODO
 * @createTime 2020年12月27日 17:44:00
 */
@DubboService
public class CodeUserRpcImpl implements CodeUserRpc {


  @Override
  public Boolean saveUser(final String email, final String code) {
    final Snowflake snowflake = IdUtil.createSnowflake(1, 1);
    UserCache.CODE_CACHE.put(
        code,
        new AuthCode()
            .setCode(code)
            .setCreateTime(new Date())
            .setEmail(email)
            .setId(snowflake.nextId()));
    return true;
  }

  @Override
  public Boolean isRegistered(final String email) {
    return UserCache.USER_MAP.get(email) != null;
  }
}
