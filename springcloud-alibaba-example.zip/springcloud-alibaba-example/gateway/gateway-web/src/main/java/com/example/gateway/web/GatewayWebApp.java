package com.example.gateway.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * @author aleng
 * @version 1.0.0
 * @className GatewayWebApp
 * @description TODO
 * @createTime 2020年12月27日 18:12:00
 */
@EnableDiscoveryClient
@SpringBootApplication
public class GatewayWebApp {

  public static void main(final String[] args) {
    SpringApplication.run(GatewayWebApp.class, args);
  }
}
